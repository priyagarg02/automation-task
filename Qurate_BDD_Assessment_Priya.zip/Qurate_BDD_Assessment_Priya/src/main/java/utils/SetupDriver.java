package utils;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;


public class SetupDriver
{
	public static WebDriver driver;
	
	
	public static void callDriver()
	{
	
	System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
	driver = new ChromeDriver();
	driver.get("http://automationpractice.com/index.php");
	System.out.println("Driver invoked");
}
}