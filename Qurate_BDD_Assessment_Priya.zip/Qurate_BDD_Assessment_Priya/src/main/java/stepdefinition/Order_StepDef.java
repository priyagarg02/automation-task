package stepdefinition;



import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utils.SetupDriver;

public class Order_StepDef extends SetupDriver{
	
	
	@Given("^user is on homepage$")
	public void user_is_already_on_homepage()  {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("My Store", title);
		System.out.println("user is on homepage ");
	}
	
	@Given("^user is on SignIn Page and enter valid credentials$")
	public void verify_LogIn_page() throws Throwable {
		WebElement login= driver.findElement(By.xpath("//a[@title='Log in to your customer account']"));
		login.click();
		WebElement uname = driver.findElement(By.xpath("//input[@name='email']"));
		uname.sendKeys("qurate@selenium.com");
		WebElement pword = driver.findElement(By.xpath("//input[@name='passwd']"));
		pword.sendKeys("qurate");
		WebElement submit = driver.findElement(By.xpath("//button[@id='SubmitLogin']"));
		submit.click();
		
	}

	@When("^user select Summer dresses$")
	public void user_select_Summer_dresses() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
				WebElement dresses = driver.findElement(By.xpath("//ul[@class='sf-menu clearfix menu-content sf-js-enabled sf-arrows']/li[2]/a[.='Dresses']"));
				Actions action = new Actions(driver);
				action.moveToElement(dresses).build().perform();
				WebElement summerDresses = driver.findElement(By.xpath("//ul[@class='sf-menu clearfix menu-content sf-js-enabled sf-arrows']/li[2]//a[.='Summer Dresses']"));
				summerDresses.click();
				System.out.println("Summer Dresses Selected");
		}
	

	@When("^Summer Dresses page display$")
	public void summer_Dresses_page_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("Summer Dresses - My Store", title);
		System.out.println("user is on Summer Dresses page ");
	}

	@Then("^Add one item to cart$")
	public void add_one_item_to_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement add_cart = driver.findElement(By.xpath("//a[@data-id-product='5']/span[.='Add to cart']"));
		add_cart.click();
		WebElement element = driver.findElement(By.xpath("//h2[contains(.,'Product successfully added to your shopping cart')]"));
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	@Then("^Click on continue shopping$")
	public void click_on_continue_shopping() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement shopCTA = driver.findElement(By.xpath("//span[@class='continue btn btn-default button exclusive-medium']/span[contains(.,'Continue shopping')]"));
		shopCTA.click();
	}

	@Then("^Add one more item to cart$")
	public void add_one_more_item_to_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement add_cart = driver.findElement(By.xpath("//a[@data-id-product='6']/span[.='Add to cart']"));
		add_cart.click();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
		
	}

	@Then("^Click on Proceed to checkout$")
	public void click_on_Proceed_to_checkout() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement checkout = driver.findElement(By.xpath("//span[contains(.,'Proceed to checkout')]"));
		checkout.click();
	}

	@Then("^validate Cart has (\\d+) products$")
	public void validate_Cart_has_products(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//WebElement totalitems = driver.findElement(By.xpath("//div[@class='shopping_cart']/a[1]/span[.='2']"));
		WebElement totalitems = driver.findElement(By.xpath("//span[text()='2 Products']"));

		totalitems.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("cart has 2 items available");
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS) ;
		//totalitems.click();
	}
	
	@And("^user is on summary page$")
	public void summary_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement summary = driver.findElement(By.xpath("//span[text()=' Summary']"));
		summary.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("Summary page displayed");
	}
	
	@When("^user click on proceed to checkout and validate address page$")
	public void address_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement checkout = driver.findElement(By.xpath("//span[text()='Proceed to checkout']"));
		checkout.click();
		WebElement addressbar = driver.findElement(By.xpath("//span[text()=' Address']"));
		addressbar.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("Address displayed");
	}
	
	@And("^user click on proceed to checkout and validate shipping page$")
	public void shipping_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement checkout = driver.findElement(By.xpath("//span[.='Proceed to checkout']"));
		checkout.click();
		WebElement addressbar = driver.findElement(By.xpath("//span[.='04. Shipping']"));
		addressbar.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("Shipping page displayed");
		WebElement TnC = driver.findElement(By.xpath("//input[@id='cgv']"));
		TnC.click();
		WebElement checkout1 = driver.findElement(By.xpath("//button[@name='processCarrier']/span[contains(.,'Proceed to checkout')]"));
		checkout1.click();
	}
	
	@And("^user is on payment page$")
	public void payment_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement payment = driver.findElement(By.xpath("//span[.='05. Payment']"));
		
		payment.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("Payment page displayed");
		WebElement wire = driver.findElement(By.xpath("//div[@id='HOOK_PAYMENT']/div[1]//span[.='(order processing will be longer)']"));
		wire.isDisplayed();
		WebElement check = driver.findElement(By.xpath("//a[contains(.,'Pay by check (order processing will be longer)')]"));
		check.isDisplayed();
	}
	
	@And("^Verify Signout link$")
	public void Signout() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement signout = driver.findElement(By.xpath("//nav[1]//a[contains(.,'Sign out')]"));
		signout.click();
		WebElement signIn_button= driver.findElement(By.xpath("//a[@title='Log in to your customer account']"));
		signIn_button.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("Sign In Text display on top of page");
		
	}
	
}
