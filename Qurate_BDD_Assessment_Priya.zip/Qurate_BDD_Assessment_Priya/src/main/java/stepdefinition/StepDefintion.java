package stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;

//import java.sql.Driver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import utils.SetupDriver;

public class StepDefintion extends SetupDriver{
	@Given("^user is already on homepage$")
	public void user_is_already_on_homepage()  {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("My Store", title);
		System.out.println("user is on homepage ");
	}

	@When("^user verify Logo of page$")
	public void user_verify_Logo_of_page()  {
	    // Write code here that turns the phrase above into concrete actions
		
		WebElement logo= driver.findElement(By.xpath("//img[@alt='My Store']"));
		logo.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("user verified logo as -Your Logo a new experience");
	}

	@Then("^user verify contact us link$")
	public void verify_contact_us_link()  {
	    // Write code here that turns the phrase above into concrete actions
		WebElement contact= driver.findElement(By.xpath("//a[@title='Contact us']"));
		contact.isDisplayed();
		Assert.assertTrue(true);
		System.out.println("Contact us Link display on page");
	}
	
	@And("^user verify signin link on page$")
	public void signin_link()  {
		WebElement signin= driver.findElement(By.xpath("//a[@title='Log in to your customer account']"));
		signin.isDisplayed();
		Assert.assertTrue(true);
	    System.out.println("Signin link display on page");
	}
	
	
	
	@Given("^Click on Signin link$")
	public void click_on_Signin_link() {
		WebElement signin= driver.findElement(By.xpath("//a[@title='Log in to your customer account']"));
	    signin.click();
	    System.out.println("User is on SignIn Page");
	}

	
	@When("^I enter username$")
	public void i_enter_qurate_selenium_com() {
	    // Write code here that turns the phrase above into concrete actions
		WebElement username = driver.findElement(By.xpath("//input[@name='email']"));
		username.sendKeys("qurate@selenium.com");
	}
	
	
	@When("^I enter password$")
	public void i_enter_qurate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement password = driver.findElement(By.xpath("//input[@name='passwd']"));
		password.sendKeys("qurate");
	}
	
	
	@When("^click on sign button$")
	public void click_on_sign_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement submit = driver.findElement(By.xpath("//button[@id='SubmitLogin']"));
		submit.click();
		
	}

	@Then("^Validate QURATE Selenium tab display on page$")
	public void validate_QURATE_Selenium_tab_display_on_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement tabname = driver.findElement(By.xpath("//span[.='Qurate Selenium']"));
		tabname.isDisplayed();
		Assert.assertTrue(true);
	    System.out.println("Qurate Selenium tab displayed on page after Signin ");
	}
	
	@Given("^user is on SignIn Page and enter invalid credentials$")
	public void verify_LogIn_page() throws Throwable {
		WebElement login= driver.findElement(By.xpath("//a[@title='Log in to your customer account']"));
		login.click();
		WebElement uname = driver.findElement(By.xpath("//input[@name='email']"));
		uname.sendKeys("qurate@selenium.in");
		WebElement pword = driver.findElement(By.xpath("//input[@name='passwd']"));
		pword.sendKeys("qurat");
		click_on_sign_button();
		
	}
	
	@Then("^Login failed message display to user$")
	public void validate_fail_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement errorMsg = driver.findElement(By.xpath("//li[.='Authentication failed.']"));
		errorMsg.isDisplayed();
		Assert.assertTrue(true);
	    System.out.println("Authentication failed message displayed");
	}
	
	}

