$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/java/feature/homepage.feature");
formatter.feature({
  "line": 1,
  "name": "Homepage and Login Page Validation",
  "description": "",
  "id": "homepage-and-login-page-validation",
  "keyword": "Feature"
});
formatter.before({
  "duration": 10479383399,
  "status": "passed"
});
formatter.scenario({
  "comments": [
    {
      "line": 3,
      "value": "#Background - to run feature before every scenario"
    }
  ],
  "line": 6,
  "name": "Validate Logo of page",
  "description": "",
  "id": "homepage-and-login-page-validation;validate-logo-of-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "user is already on homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "user verify Logo of page",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "user verify contact us link",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "user verify signin link on page",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Click on Signin link",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "I enter username",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "I enter password",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "click on sign button",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Validate QURATE Selenium tab display on page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefintion.user_is_already_on_homepage()"
});
formatter.result({
  "duration": 114786108,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.user_verify_Logo_of_page()"
});
formatter.result({
  "duration": 88156745,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.verify_contact_us_link()"
});
formatter.result({
  "duration": 70969283,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.signin_link()"
});
formatter.result({
  "duration": 44319038,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.click_on_Signin_link()"
});
formatter.result({
  "duration": 2155772273,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.i_enter_qurate_selenium_com()"
});
formatter.result({
  "duration": 173252427,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.i_enter_qurate()"
});
formatter.result({
  "duration": 107259980,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.click_on_sign_button()"
});
formatter.result({
  "duration": 2542738073,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.validate_QURATE_Selenium_tab_display_on_page()"
});
formatter.result({
  "duration": 47998754,
  "status": "passed"
});
formatter.after({
  "duration": 724331355,
  "status": "passed"
});
formatter.before({
  "duration": 10901339591,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Validate scenario when user enter invalid credentials",
  "description": "",
  "id": "homepage-and-login-page-validation;validate-scenario-when-user-enter-invalid-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user is on SignIn Page and enter invalid credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "Login failed message display to user",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefintion.verify_LogIn_page()"
});
formatter.result({
  "duration": 3805164414,
  "status": "passed"
});
formatter.match({
  "location": "StepDefintion.validate_fail_message()"
});
formatter.result({
  "duration": 56044438,
  "status": "passed"
});
formatter.after({
  "duration": 714584373,
  "status": "passed"
});
formatter.uri("src/main/java/feature/order.feature");
formatter.feature({
  "line": 1,
  "name": "Cart Page Validation",
  "description": "",
  "id": "cart-page-validation",
  "keyword": "Feature"
});
formatter.before({
  "duration": 11064971739,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Test_Scenario to Add item to cart",
  "description": "",
  "id": "cart-page-validation;test-scenario-to-add-item-to-cart",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "user is on homepage",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user is on SignIn Page and enter valid credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user select Summer dresses",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Summer Dresses page display",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Add one item to cart",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "Click on continue shopping",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "Add one more item to cart",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "Click on Proceed to checkout",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "validate Cart has 2 products",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "user is on summary page",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "user click on proceed to checkout and validate address page",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user click on proceed to checkout and validate shipping page",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "user is on payment page",
  "keyword": "Then "
});
formatter.step({
  "line": 19,
  "name": "Verify Signout link",
  "keyword": "And "
});
formatter.match({
  "location": "Order_StepDef.user_is_already_on_homepage()"
});
formatter.result({
  "duration": 8707871,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.verify_LogIn_page()"
});
formatter.result({
  "duration": 4904420119,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.user_select_Summer_dresses()"
});
formatter.result({
  "duration": 6587651699,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.summer_Dresses_page_display()"
});
formatter.result({
  "duration": 9936329,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.add_one_item_to_cart()"
});
formatter.result({
  "duration": 1224717129,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.click_on_continue_shopping()"
});
formatter.result({
  "duration": 81534884,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.add_one_more_item_to_cart()"
});
formatter.result({
  "duration": 92714892,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.click_on_Proceed_to_checkout()"
});
formatter.result({
  "duration": 2277951789,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "2",
      "offset": 18
    }
  ],
  "location": "Order_StepDef.validate_Cart_has_products(int)"
});
formatter.result({
  "duration": 73308347,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.summary_page()"
});
formatter.result({
  "duration": 37266456,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.address_page()"
});
formatter.result({
  "duration": 1375913559,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.shipping_page()"
});
formatter.result({
  "duration": 2710687350,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.payment_page()"
});
formatter.result({
  "duration": 126296677,
  "status": "passed"
});
formatter.match({
  "location": "Order_StepDef.Signout()"
});
formatter.result({
  "duration": 1622693763,
  "status": "passed"
});
formatter.after({
  "duration": 752352689,
  "status": "passed"
});
});